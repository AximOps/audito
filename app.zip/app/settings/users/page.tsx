"use client";

import { useEffect, useState } from "react";
import { Check, Loader2, Shield, UserPlus } from "lucide-react";
import AppShell from "@/components/app-shell";
import { createClient, getCurrentProfile } from "@/lib/auth";
import { ROLE_OPTIONS, isAdmin } from "@/lib/rbac";

export default function UsersPage() {
  const [profile, setProfile] = useState<any>(null);
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  async function load() {
    const { profile } = await getCurrentProfile();
    setProfile(profile);
    if (!profile || !isAdmin(profile.role)) { setLoading(false); return; }
    const { data } = await createClient().from("user_profiles").select("id,full_name,job_title,role,status,created_at").eq("organization_id", profile.organization_id).order("created_at");
    setRows(data || []);
    setLoading(false);
  }
  useEffect(()=>{load()},[]);

  async function saveRole(id: string, role: string) {
    setSaving(id); setMessage("");
    const { error } = await createClient().from("user_profiles").update({ role }).eq("id", id);
    if (error) setMessage(error.message); else setMessage("Role updated successfully.");
    await load(); setSaving(null);
  }

  async function saveStatus(id: string, status: string) {
    setSaving(id); setMessage("");
    const { error } = await createClient().from("user_profiles").update({ status }).eq("id", id);
    if (error) setMessage(error.message); else setMessage("User status updated.");
    await load(); setSaving(null);
  }

  return <AppShell requiredPermission="users">
    <div className="max-w-6xl mx-auto">
      <div className="flex items-end justify-between mb-7"><div><h1 className="text-2xl font-semibold">Users & Roles</h1><p className="text-sm text-gray-500 mt-1">Control who can view and manage each area of AuditOps.</p></div><button className="rounded-lg bg-slate-950 text-white px-4 py-2 text-sm flex items-center gap-2"><UserPlus size={16}/> Invite User</button></div>
      <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 mb-5 text-sm text-blue-800 flex gap-3"><Shield size={18} className="shrink-0 mt-0.5"/><div><strong>RBAC is enabled.</strong> Permissions are enforced in the database as well as the UI. User invitations are the next workflow to add; for now, provision accounts in Supabase Auth and assign them to this organization.</div></div>
      {message && <div className="mb-5 rounded-lg bg-emerald-50 border border-emerald-100 text-emerald-700 p-3 text-sm flex items-center gap-2"><Check size={15}/>{message}</div>}
      <div className="bg-white border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b"><h2 className="font-semibold">Organization members</h2><p className="text-xs text-gray-500 mt-1">Assign the least-privileged role needed for each user.</p></div>
        {loading ? <div className="p-8 text-sm text-gray-500">Loading users…</div> : rows.length === 0 ? <div className="p-8 text-sm text-gray-500">No organization users found.</div> : <div className="divide-y">{rows.map(r=><div key={r.id} className="px-5 py-4 flex items-center gap-5"><div className="h-9 w-9 rounded-full bg-gray-100 grid place-items-center text-xs font-semibold">{(r.full_name||"U").split(" ").map((x:string)=>x[0]).slice(0,2).join("").toUpperCase()}</div><div className="flex-1 min-w-0"><div className="font-medium text-sm">{r.full_name || "Unnamed user"}</div><div className="text-xs text-gray-500 mt-1">{r.job_title || "No job title"}</div></div><select value={r.role} disabled={saving===r.id} onChange={e=>saveRole(r.id,e.target.value)} className="border rounded-lg px-3 py-2 text-sm bg-white">{ROLE_OPTIONS.map(role=><option key={role}>{role}</option>)}</select><select value={r.status} disabled={saving===r.id} onChange={e=>saveStatus(r.id,e.target.value)} className="border rounded-lg px-3 py-2 text-sm bg-white w-32"><option>Active</option><option>Suspended</option></select>{saving===r.id && <Loader2 size={16} className="animate-spin text-gray-400"/>}</div>)}</div>}
      </div>
    </div>
  </AppShell>;
}
