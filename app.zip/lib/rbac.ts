export type Role =
  | "Organization Admin"
  | "Compliance Manager"
  | "Security Manager"
  | "IT Manager"
  | "Contributor"
  | "Auditor / Read Only";

export const ROLE_OPTIONS: Role[] = [
  "Organization Admin",
  "Compliance Manager",
  "Security Manager",
  "IT Manager",
  "Contributor",
  "Auditor / Read Only",
];

export const PERMISSIONS = {
  dashboard: ["Organization Admin", "Compliance Manager", "Security Manager", "IT Manager", "Contributor", "Auditor / Read Only"],
  activities: ["Organization Admin", "Compliance Manager", "Contributor", "Auditor / Read Only"],
  evidence: ["Organization Admin", "Compliance Manager", "Contributor", "Auditor / Read Only"],
  policies: ["Organization Admin", "Compliance Manager", "Auditor / Read Only"],
  vulnerabilities: ["Organization Admin", "Security Manager", "IT Manager", "Contributor", "Auditor / Read Only"],
  assets: ["Organization Admin", "Security Manager", "IT Manager", "Contributor", "Auditor / Read Only"],
  accessReviews: ["Organization Admin", "Security Manager", "IT Manager", "Contributor", "Auditor / Read Only"],
  findings: ["Organization Admin", "Compliance Manager", "Security Manager", "IT Manager", "Contributor", "Auditor / Read Only"],
  exceptions: ["Organization Admin", "Compliance Manager", "Security Manager", "IT Manager", "Auditor / Read Only"],
  vendors: ["Organization Admin", "Compliance Manager", "Auditor / Read Only"],
  reports: ["Organization Admin", "Compliance Manager", "Security Manager", "IT Manager", "Auditor / Read Only"],
  users: ["Organization Admin"],
  auditLog: ["Organization Admin", "Compliance Manager", "Auditor / Read Only"],
} satisfies Record<string, readonly Role[]>;

export function can(role: string | null | undefined, permission: keyof typeof PERMISSIONS) {
  return !!role && (PERMISSIONS[permission] as readonly string[]).includes(role);
}

export function isAdmin(role: string | null | undefined) {
  return role === "Organization Admin";
}
